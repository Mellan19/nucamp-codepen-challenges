let firstNamesArray = ['Violet', 'Charlie', 'Veruca', 'Mike', 'Augustus'];
let lastNamesArray = ['Beauregarde', 'Bucket', 'Salt', 'Teavee', 'Gloop'];

firstNamesArray = firstNamesArray.reverse();
lastNamesArray = lastNamesArray.reverse();

for (let i = 0; i < firstNamesArray.length; i++) {
  console.log(firstNamesArray[i] + " " + lastNamesArray[i]);
}

