const inputEl = document.querySelector("input");
inputEl.addEventListener('keyup', fixLength);

function fixLength() {
  var text=inputEl.value;
  if(text.length>12) {
    inputEl.value=text.slice(0,12);
  }
};
   