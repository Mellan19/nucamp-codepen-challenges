
function getMembershipPerks(mLevel) {
/* Your switch statement should be written below this line.*/
  switch(mLevel) {
    case 'Gold':
      console.log('Unlimited Free Plays');
      /*You can omit this break because Gold memberships have Unlimited Free Plays*/
      /*and VIP Room Access, when it runs it will log both for Gold.*/
    case 'Silver':
      console.log('VIP Room Access');
      break;
    case 'Bronze':
      console.log('VIP Room Access on Weekdays');
      break;
    default:
      console.log('Invalid membership level')
  }
}
getMembershipPerks('Gold');
/* After you make changes, you will need to click the Run button on the upper right. Auto-updating preview has been turned off for this Codepen. */